
document.getElementById('generateBtn').addEventListener('click', async () => {
  const url = document.getElementById('videoUrl').value;
  if(!url) return alert('Please paste a YouTube URL');
  document.getElementById('loader').style.display = 'block';
  document.getElementById('output').textContent = '';
  try {
    const resp = await fetch('/process', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({video_url: url})
    });
    const data = await resp.json();
    document.getElementById('output').textContent = data.summary;
  } catch (err) {
    document.getElementById('output').textContent = 'Error: ' + err;
  } finally {
    document.getElementById('loader').style.display = 'none';
  }
});
